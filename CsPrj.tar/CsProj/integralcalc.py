import tkinter as tk
from tkinter import ttk
import tkinter.messagebox as msgbox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import quad
import sympy as sp
from PIL import Image, ImageTk

def instructions():
    msgbox.showinfo("Instructions", (
        "Welcome to the Simple Integral Calculator!\n\n"
        "1. Enter a mathematical function in the provided box.\n"
        "   Example: x**2 + 2*x + 1\n\n"
        "2. Click 'Calculate Definite Integral' to see the result for a specific range.\n"
        "   The graph of the function and its integral will be displayed.\n\n"
        "3. Click 'Calculate Indefinite Integral' to see the result up to infinity.\n\n"
        "4. You can adjust the integration limits for the definite integral.\n\n"
        "5. Have fun exploring different functions!"
    ))

def format_instructions():
    msgbox.showinfo("Function Format", (
        "Function Format:\n\n"
        "1. Use 'x' as the variable (e.g., x**2, sin(x)).\n"
        "2. Use standard Python operators: +, -, *, /, **.\n"
        "3. Use standard math functions: sin, cos, tan, exp, log, sqrt, etc.\n\n"
        "Example: x**2 + 2*x + 1"
    ))

def calculate_definite_integral():
    expr = function_entry.get()
    lower_limit = float(lower_limit_entry.get())
    upper_limit = float(upper_limit_entry.get())

    try:
        def func(x):
            return eval(expr)

        result, _ = quad(func, lower_limit, upper_limit)

        result_label.config(text=f"Definite Integral Result: {result:.4f}")

        x_vals = np.linspace(lower_limit, upper_limit, 1000)
        y_vals = func(x_vals)

        axes.clear()
        axes.plot(x_vals, y_vals, label=f'Function: {expr}')
        axes.plot(x_vals, [quad(func, lower_limit, x)[0] for x in x_vals], label='Integral', linestyle='--')
        axes.legend()
        axes.set_xlabel('X-axis')
        axes.set_ylabel('Y-axis')
        axes.set_title('Function and Its Definite Integral')

        img = plot_to_image(fig)
        img_label.config(image=img)
        img_label.image = img

    except Exception as e:
        result_label.config(text=f"Error: {str(e)}")

def calculate_indefinite_integral():
    expr = function_entry.get()
    
    try:
        x = sp.symbols('x')
        symbolic_function = sp.sympify(expr)
        indefinite_integral = sp.integrate(symbolic_function, x)

        result_label.config(text=f"Indefinite Integral Result: {indefinite_integral}")

        img_label.config(image=None)

    except Exception as e:
        result_label.config(text=f"Error: {str(e)}")

def plot_to_image(fig):
    fig.canvas.draw()
    width, height = fig.canvas.get_width_height()
    img = Image.frombytes('RGB', (width, height), fig.canvas.tostring_rgb())
    return ImageTk.PhotoImage(img)

root = tk.Tk()
root.title("Simple Integral Calculator")

function_label = ttk.Label(root, text="Enter Function:")
function_label.pack(pady=10)

function_entry = ttk.Entry(root, width=30)
function_entry.pack(pady=10)

lower_limit_label = ttk.Label(root, text="Lower Limit:")
lower_limit_label.pack(pady=5)

lower_limit_entry = ttk.Entry(root, width=10)
lower_limit_entry.pack(pady=5)

upper_limit_label = ttk.Label(root, text="Upper Limit:")
upper_limit_label.pack(pady=5)

upper_limit_entry = ttk.Entry(root, width=10)
upper_limit_entry.pack(pady=5)

btn_calculate_definite = ttk.Button(root, text="Calculate Definite Integral", command=calculate_definite_integral)
btn_calculate_definite.pack(pady=10)

btn_calculate_indefinite = ttk.Button(root, text="Calculate Indefinite Integral", command=calculate_indefinite_integral)
btn_calculate_indefinite.pack(pady=10)

result_label = ttk.Label(root, text="Integral Result: ")
result_label.pack(pady=10)

fig, axes = plt.subplots(figsize=(5, 4), dpi=100)
canvas = FigureCanvasTkAgg(fig, master=root)
canvas_widget = canvas.get_tk_widget()
canvas_widget.pack()

img_label = ttk.Label(root)
img_label.pack()

instructions_window = tk.Toplevel(root)
instructions_window.title("Instructions")

instructions_label = ttk.Label(instructions_window, text="Welcome to the Integral Calculator.\n"
                                                        "Click the button below to view instructions.")
instructions_label.pack(pady=10)

btn_instructions = ttk.Button(instructions_window, text="Show Instructions", command=instructions)
btn_instructions.pack(pady=10)

function_format_window = tk.Toplevel(root)
function_format_window.title("Function Format")

function_format_label = ttk.Label(function_format_window, text="Click the button below to view the function format.")
function_format_label.pack(pady=10)

btn_function_format = ttk.Button(function_format_window, text="Function Format", command=format_instructions)
btn_function_format.pack(pady=10)

root.mainloop()



